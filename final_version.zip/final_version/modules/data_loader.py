def load_data():

    '''
    setup_file = open('data/setup.stp').read().split('\n')
    setup = {}
    for i in setup_file:
        if i == '':
            break
        try:
            if '.' in i.split(' = ')[1]:
                setup.update({i.split(' = ')[0]: float(i.split(' = ')[1])})
            else:
                setup.update({i.split(' = ')[0]: int(i.split(' = ')[1])})
        except ValueError:
            setup.update({i.split(' = ')[0]: i.split(' = ')[1]})

    del setup_file

    # ---
    '''

    enginedata_file = open('data/enginedata.ed').read().split('\n')
    enginedata = {}

    for i in enginedata_file:
        if i == '':
            break
        if len(i.split(' = ')[1].split()) != 1:
            enginedata_arr = []
            try:
                if '.' in i.split(' = ')[1].split()[0]:
                    for j in i.split(' = ')[1].split():
                        enginedata_arr.append(float(j))
                else:
                    for j in i.split(' = ')[1].split():
                        enginedata_arr.append(int(j))
            except ValueError:
                for j in i.split(' = ')[1].split():
                    enginedata_arr.append(j)
            enginedata.update({i.split(' = ')[0]: enginedata_arr})

        else:
            try:
                if '.' in i.split(' = ')[1]:
                    enginedata.update({i.split(' = ')[0]: float(i.split(' = ')[1])})
                else:
                    enginedata.update({i.split(' = ')[0]: int(i.split(' = ')[1])})
            except ValueError:
                enginedata.update({i.split(' = ')[0]: i.split(' = ')[1]})

    del enginedata_file

    '''
    # ---

    gamedata_file = open('data/gamedata.gd').read().split('\n')
    gamedata = {}

    for i in gamedata_file:
        if i == '':
            break
        if len(i.split(' = ')[1].split()) != 1:
            gamedata_arr = []
            try:
                if '.' in i.split(' = ')[1].split()[0]:
                    for j in i.split(' = ')[1].split():
                        gamedata_arr.append(float(j))
                else:
                    for j in i.split(' = ')[1].split():
                        gamedata_arr.append(int(j))
            except ValueError:
                for j in i.split(' = ')[1].split():
                    gamedata_arr.append(j)
            gamedata.update({i.split(' = ')[0]: gamedata_arr})

        else:
            try:
                if '.' in i.split(' = ')[1]:
                    gamedata.update({i.split(' = ')[0]: float(i.split(' = ')[1])})
                else:
                    gamedata.update({i.split(' = ')[0]: int(i.split(' = ')[1])})
            except ValueError:
                gamedata.update({i.split(' = ')[0]: i.split(' = ')[1]})

    del gamedata_file
    '''

    return enginedata


def load_level(path):
    level_map = open(path + '/map.map').read()
    level_pos = open(path + '/positions.pos').read()
    level_inf = open(path + '/info.inf').read()
    level_dor = open(path + '/doors.dor').read()

    res_map = [[int(j) for j in i.split()] for i in level_map.split('\n') if i != '']
    res_pos = {}
    res_inf = {}
    res_dor = [[*[int(j) if i.split().index(j) != 3 else float(j) for j in i.split()]] for i in level_dor.split('\n') if i != '']

    for i in level_pos.split('\n'):
        if not i:
            break
        if res_pos.get(i.split(' = ')[0]) is None:
            res_pos.update({i.split(' = ')[0]: [[float(j) for j in i.split(' = ')[1].split()]]})
        else:
            res_pos[i.split(' = ')[0]].append([float(j) for j in i.split(' = ')[1].split()])

    for i in level_inf.split('\n'):
        if i != '':
            if len(i.split(' = ')[1].split()) != 1:
                level_inf_arr = []
                try:
                    if '.' in i.split(' = ')[1].split()[0]:
                        for j in i.split(' = ')[1].split():
                            level_inf_arr.append(float(j))
                    else:
                        for j in i.split(' = ')[1].split():
                            level_inf_arr.append(int(j))
                except ValueError:
                    for j in i.split(' = ')[1].split()[0]:
                        level_inf_arr.append(j)
                res_inf.update({i.split(' = ')[0]: level_inf_arr})
            else:
                try:
                    if '.' in i.split(' = ')[1]:
                        res_inf.update({i.split(' = ')[0]: float(i.split(' = ')[1])})
                    else:
                        res_inf.update({i.split(' = ')[0]: int(i.split(' = ')[1])})
                except ValueError:
                    res_inf.update({i.split(' = ')[0]: i.split(' = ')[1]})

    return res_map, res_pos, res_inf, res_dor