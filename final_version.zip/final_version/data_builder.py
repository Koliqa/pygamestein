tile_width = input('Enter the width of single tile: ')
tile_height = input('Enter the height of single tile: ')
doors = input('Enter numbers of wall tiles which is supposed to be doors, space as a separator: ')
colorkey = input('Enter the sprite & dev tileset\'s colorkey: ')

if len(doors.split()) == 1:
    doors = doors + ' ' + doors

doc = open('data\enginedata.ed', 'w')
doc.write('camera = player\nbase_fps = 60\nwalls_tile_path = data/GFX/walls.bmp\nsprites_tile_path = data/GFX/sprites.bmp\ndev_tile_path = data/GFX/dev.bmp\n')
doc.write('tile_width = ' + tile_width + '\n')
doc.write('tile_height = ' + tile_height + '\n')
doc.write('doors = ' + doors + '\n')
doc.write('colorkey = ' + colorkey)